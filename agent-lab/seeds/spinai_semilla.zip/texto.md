# SpinAI — Manifiesto arquitectónico

## Identidad

**SpinAI — Dibuja con el movimiento.**

SpinAI es una aplicación móvil de pintura cinética asistida por inteligencia artificial, construida sobre AI-APPS.

Permite crear composiciones mediante la interacción entre instrumentos de pintura, comportamientos programables y una superficie circular giratoria.

El usuario controla la creación. El sistema calcula sus resultados y la inteligencia artificial acompaña la exploración.

## Experiencia

SpinAI representa un estudio artístico cuyo elemento principal es un torno virtual.

El usuario puede pintar libremente o seleccionar presets que automatizan comportamientos espaciales y temporales del instrumento.

Cada preset es configurable y se ejecuta mientras el usuario mantiene el contacto con la superficie.

El dibujo resultante depende del comportamiento seleccionado, los gestos del usuario y el movimiento del torno.

La aplicación permite experimentar con diferentes instrumentos, colores, velocidades, materiales y configuraciones de modulación.

## Motor de pintura cinética

El sistema Dart gobierna la rotación, la interacción táctil, la deposición de pintura y la construcción de la composición.

Los comportamientos se definen mediante funciones matemáticas y señales de control que pueden modificar parámetros espaciales y temporales.

El motor admite modulaciones, envolventes, osciladores, secuencias y relaciones de sincronización.

Los presets son configuraciones reutilizables de estos mecanismos, no dibujos predeterminados.

La simulación es independiente de la representación visual y conserva la información necesaria para reconstruir y editar las obras.

## Interfaz

La interfaz prioriza la superficie de creación y los controles utilizados durante la actividad.

El torno permanece completamente visible.

El instrumento activo, el preset seleccionado y sus parámetros relevantes son accesibles sin abandonar el estudio.

Las funciones secundarias no compiten con el espacio de pintura.

La organización de los controles responde al flujo de trabajo del usuario, no a la estructura interna del software.

## Inteligencia artificial

SpinAI incorpora asistencia creativa y técnica contextual.

El sistema analiza la actividad mediante cálculos realizados en Dart y determina cuándo existe una oportunidad de intervención.

La IA recibe el contexto pertinente y propone observaciones, consejos o experimentos relacionados con la obra.

Sus intervenciones son ocasionales, breves y no invasivas.

La IA no gobierna el torno, no realiza los cálculos del motor y no modifica la obra por iniciativa propia.

## Arquitectura e integración

SpinAI pertenece a `apps/` como aplicación independiente de AI-APPS.

Es responsable de su experiencia, estado, reglas, instrumentos, modulaciones, presets, materiales, proyectos, interfaz y asistencia contextual.

Utiliza el subsistema transversal `ai/` para ejecutar operaciones de inteligencia artificial.

Los prompts, contextos, validaciones y criterios particulares de intervención permanecen bajo la responsabilidad de SpinAI.

Los componentes compartidos se reutilizan cuando satisfacen una necesidad real.

La organización interna responde a las necesidades de implementación, sin imponer componentes o abstracciones anticipadas.

SpinAI funciona sin disponibilidad de inteligencia artificial.

## Visión

SpinAI convierte el movimiento, el tiempo y la geometría en instrumentos de creación artística.

Su propósito es ofrecer una experiencia accesible de experimentación cinética, combinando control directo, automatización matemática y acompañamiento inteligente.

**El usuario crea, el movimiento transforma y la inteligencia artificial acompaña.**
